angular.module('example-app.modules', [
  require('./doge-debug').name
]);