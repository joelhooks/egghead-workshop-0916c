module.exports = {
  port: 3444,
  static_site_root: __dirname + '/../build' //up a dir and find build
};