exports.config = {

  specs: [
    './tests/**/*.spec.js'
  ],

  baseUrl: 'http://localhost:3444'
};