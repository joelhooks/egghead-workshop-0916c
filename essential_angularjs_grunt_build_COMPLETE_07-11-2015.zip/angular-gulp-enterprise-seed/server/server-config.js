module.exports = {
  port: 3444,
  data_location: __dirname + '/../data/',
  rest_base_url: '/api',
  static_site_root: __dirname + '/../build' //up a dir and find build
};