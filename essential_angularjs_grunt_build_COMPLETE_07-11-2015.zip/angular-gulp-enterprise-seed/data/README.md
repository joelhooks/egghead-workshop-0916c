This directory structure represents a portion of: 

### https://api.github.com/