angular.module("project-seed.config.constants", [])

.constant("config", {
	"isDev": true,
	"baseApiUrl": "/api",
	"companyName": "Application"
})

.constant('baseApiUrl', 'https://api.github.com')

;