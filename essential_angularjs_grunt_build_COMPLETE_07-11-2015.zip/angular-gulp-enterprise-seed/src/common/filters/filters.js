angular.module('project-seed.filters', [
  'project-seed.filters.dates'
])

;
