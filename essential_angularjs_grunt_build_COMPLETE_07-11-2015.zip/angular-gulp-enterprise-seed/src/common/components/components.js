angular.module('project-seed.components', [

])

;
