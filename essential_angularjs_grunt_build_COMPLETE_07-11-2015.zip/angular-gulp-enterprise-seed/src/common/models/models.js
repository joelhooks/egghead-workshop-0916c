angular.module('project-seed.common.models', [
  'ps.models.user-list'
])
;


