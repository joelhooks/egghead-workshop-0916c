angular.module('et.utils', [
  
])

;
